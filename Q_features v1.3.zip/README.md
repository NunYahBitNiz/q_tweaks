# Android Q modifications
This enables hidden settings in android Q in the form of an executable script

## How to Use?
Open a terminal app and su or adb shell and run "qmod"

## What features are listed?
Currently there is dark theming, new navbar gestures, lockscreen clocks, desktop mode, and chat bubbles. 
More information is in the script itself

## Compatibility
* Android Q+

