# Android Q modifications
This enables hidden settings in android Q in the form of an executable script

## How to Use?
Open a terminal app and su or adb shell and run "qmod"

## What features are listed?
Currently there is dark theming and the new navbar gestures. More information in the script

## Compatibility
* Android Q+

